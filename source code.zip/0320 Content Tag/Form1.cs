﻿// Course: Azure Image Analysis
// Loy Vanich 2021
// Example:Get image tag

using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System.Collections.Generic;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test
{
    public partial class Form1 : Form
    {
        string subscriptionKey = "9f86dd377d9a4e61b452ac3304f68988";
        string endpoint = "https://stu2021comvis.cognitiveservices.azure.com/";
        private const string myImage = @"L:\temp2\campting010.jpg";
        private const string NL = "\r\n";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Load(myImage);
        }

        public ComputerVisionClient Authenticate(string endpoint, string key)
        {
            textBox1.Text += $"Authenticate{NL}{NL}";
            ComputerVisionClient client =
              new ComputerVisionClient(new ApiKeyServiceClientCredentials(key))
              { Endpoint = endpoint };
            return client;
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            ComputerVisionClient client = Authenticate(endpoint, subscriptionKey);
            await AnalyzeLocal(client, myImage);
            textBox1.Text += $"Task complete{NL}";
        }

        public async Task AnalyzeLocal(ComputerVisionClient client, string localImage)
        {
            textBox1.Text += $"Analyzing local image: " + 
                $"{Path.GetFileName(localImage)}...{NL}{NL}";

            List<VisualFeatureTypes?> myFeature = new List<VisualFeatureTypes?>()
            {
                VisualFeatureTypes.Tags
            };

            ImageAnalysis myResult;
            using (Stream myStream = File.OpenRead(localImage))
            {
                myResult = await client.AnalyzeImageInStreamAsync(myStream, visualFeatures: myFeature);
            }
            textBox1.Text += $"Got analyze result!{NL}{NL}";

            if (null != myResult.Tags)
            {
                textBox1.Text += $"Tags:{NL}";
                foreach (var tag in myResult.Tags)
                {
                    textBox1.Text += $"{tag.Name} {tag.Confidence}{NL}";
                }
            }
        }
    }
}
