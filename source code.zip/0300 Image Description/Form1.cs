﻿// Course: Azure Image Analysis
// Loy Vanich 2021
// Example:Get image description

using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test
{
    public partial class Form1 : Form
    {
        string subscriptionKey = "9f86dd377d9a4e61b452ac3304f68988";
        string endpoint = "https://stu2021comvis.cognitiveservices.azure.com/";
        //private const string myImage = @"L:\temp2\jungle010.jpg";
        private const string myImage = @"L:\temp2\playground010.jpg";
        private const string NL = "\r\n";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Load(myImage);
        }

        public ComputerVisionClient Authenticate(string endpoint, string key)
        {
            textBox1.Text += $"Authenticate{NL}{NL}";
            ComputerVisionClient client =
              new ComputerVisionClient(new ApiKeyServiceClientCredentials(key))
              { Endpoint = endpoint };
            return client;
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            ComputerVisionClient client = Authenticate(endpoint, subscriptionKey);
            await AnalyzeLocal(client, myImage);
            textBox1.Text += $"Task complete{NL}";
        }

        public async Task AnalyzeLocal(ComputerVisionClient client, string localImage)
        {
            textBox1.Text += $"Analyzing local image: " + 
                $"{Path.GetFileName(localImage)}...{NL}{NL}";

            using (Stream myStream = File.OpenRead(localImage))
            {
                ImageDescription results = await client.DescribeImageInStreamAsync(myStream);
                textBox1.Text += $"Got analyze result!{NL}{NL}";

                foreach (var v in results.Captions)
                {
                    textBox1.Text += $"Description: {v.Text}{NL}{NL}" +    
                        $"Confidence: {v.Confidence}{NL}" +
                        $"{NL}{NL}";
                }
            }
        }
    }
}
