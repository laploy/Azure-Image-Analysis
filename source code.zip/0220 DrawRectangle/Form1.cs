﻿// Course: Azure Image Analysis
// Loy Vanich 2021
// Example: Object detection in .NET Core 5 Winform
// Add NuGet package
// Microsoft.Azure.CognitiveServices.Vision.ComputerVision

using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0220_DrawRectangle
{
    public partial class Form1 : Form
    {
        private string subscriptionKey = "9f86dd377d9a4e61b452ac3304f68988";
        private string endpoint = "https://stu2021comvis.cognitiveservices.azure.com/";
        private List<Rectangle> myRec = new List<Rectangle>();
        private Color[] myColor = {Color.Red, Color.Yellow, Color.SpringGreen, Color.Aqua };
        private int counter = 0;
        private const int IMAGE_MAX = 5;
        private string[] myImageArray = new string[IMAGE_MAX];
        private int imageCount = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            myImageArray[0] = @"L:\temp2\cake020.jpg";
            myImageArray[1] = @"L:\temp2\desk010.jpg";
            myImageArray[2] = @"L:\temp2\kitchen010.jpg";
            myImageArray[3] = @"L:\temp2\traffic010.jpg";
            myImageArray[4] = @"L:\temp2\popecat010.jpg";
            pictureBox1.Load(myImageArray[imageCount]);
        }

        public ComputerVisionClient Authenticate(string endpoint, string key)
        {
            textBox1.Text += "Authenticate\r\n";
            ComputerVisionClient client =
              new ComputerVisionClient(new ApiKeyServiceClientCredentials(key))
              { Endpoint = endpoint };
            return client;
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            ComputerVisionClient client = Authenticate(endpoint, subscriptionKey);
            await DetectObjectsLocal(client, myImageArray[imageCount]);
            textBox1.Text += "Object detection is complete.\r\n";
        }

        public async Task DetectObjectsLocal(ComputerVisionClient client, string localImage)
        {
            textBox1.Text += $"Detecting objects in local image {Path.GetFileName(localImage)}...\r\n\r\n";
            using (Stream stream = File.OpenRead(localImage))
            {
                DetectResult results = await client.DetectObjectsInStreamAsync(stream);

                textBox1.Text += "Detected objects:\r\n\r\n";
                Rectangle r = new Rectangle();
                foreach (var v in results.Objects)
                {
                    textBox1.Text += $"== {v.ObjectProperty} ==\r\n" +    // detected object name
                        $"with confidence {v.Confidence}\r\n" + 
                        "at location " + 
                        $"x: {v.Rectangle.X}, " +
                        $"y: {v.Rectangle.Y}, " + 
                        $"h: {v.Rectangle.H}, " + 
                        $"w: {v.Rectangle.W}" + 
                        "\r\n\r\n";
                    // draw rectangle
                    r.X = v.Rectangle.X;
                    r.Y = v.Rectangle.Y;
                    r.Width = v.Rectangle.W;
                    r.Height = v.Rectangle.H;
                    myRec.Add(r);
                    // draw label
                    Label myLabel = new Label();
                    myLabel.Text = v.ObjectProperty;
                    myLabel.Font = new Font("Consolas", 12, FontStyle.Bold);
                    myLabel.Parent = pictureBox1;
                    myLabel.Top = v.Rectangle.Y - myLabel.Height;
                    myLabel.Left = v.Rectangle.X;
                    myLabel.BackColor = Color.Red;
                    myLabel.ForeColor = Color.White;
                    myLabel.AutoSize = true;
                }
                pictureBox1.Refresh();
            }
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            foreach (var r in myRec)
            {
                if (++counter == myColor.Count()) counter = 0;
                Pen myPen = new Pen(myColor[counter], 3);
                e.Graphics.DrawRectangle(myPen, r);
            }
        }

        private void buttonPrev_Click(object sender, EventArgs e)
        {
            myRec.Clear();
            pictureBox1.Controls.Clear();
            if (--imageCount <= 0) imageCount = 0;
            pictureBox1.Load(myImageArray[imageCount]);
        }

        private void buttonNext_Click(object sender, EventArgs e)
        {
            myRec.Clear();
            pictureBox1.Controls.Clear();
            if (++imageCount == myImageArray.Count()) imageCount = myImageArray.Count()-1;
            pictureBox1.Load(myImageArray[imageCount]);
        }
    }
}
