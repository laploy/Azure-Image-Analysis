﻿// Course: Azure Image Analysis
// Loy Vanich 2021
// Example: Detect object in image file located on web
// Add NuGet package
// Microsoft.Azure.CognitiveServices.Vision.ComputerVision

using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0230_DetectOnLine
{
    public partial class Form1 : Form
    {
        private string subscriptionKey = "9f86dd377d9a4e61b452ac3304f68988";
        private string endpoint = "https://stu2021comvis.cognitiveservices.azure.com/";
        private List<Rectangle> myRec = new List<Rectangle>();
        private Color[] myColor = {Color.Red, Color.Yellow, Color.SpringGreen, Color.Aqua };
        //private const string IMAGE_URL = "https://github.com/laploy/Azure-Image-Analysis/blob/main/images/cake020.jpg?raw=true";
        private const string IMAGE_URL = "https://www.mandatory.com/assets/uploads/2019/01/BurgerandFries-e1548176960179.jpg";
        private int counter = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.ImageLocation = IMAGE_URL;
        }

        public ComputerVisionClient Authenticate(string endpoint, string key)
        {
            textBox1.Text += "Authenticate\r\n";
            ComputerVisionClient client =
              new ComputerVisionClient(new ApiKeyServiceClientCredentials(key))
              { Endpoint = endpoint };
            return client;
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            ComputerVisionClient client = Authenticate(endpoint, subscriptionKey);
            await DetectObjectsOnline(client);
            textBox1.Text += "Object detection is complete.\r\n";
        }

        public async Task DetectObjectsOnline(ComputerVisionClient client)
        {
            DetectResult results = await client.DetectObjectsAsync(IMAGE_URL);
            textBox1.Text += "Detected objects:\r\n\r\n";
            Rectangle r = new Rectangle();
            foreach (var obj in results.Objects)
            {
                textBox1.Text += $"== {obj.ObjectProperty} ==\r\n" +    // detected object name
                    $"with confidence {obj.Confidence}\r\n" + 
                    "at location " + 
                    $"x: {obj.Rectangle.X}, " +
                    $"y: {obj.Rectangle.Y}, " + 
                    $"h: {obj.Rectangle.H}, " + 
                    $"w: {obj.Rectangle.W}" + 
                    "\r\n\r\n";
                // draw rectangle
                r.X = obj.Rectangle.X;
                r.Y = obj.Rectangle.Y;
                r.Width = obj.Rectangle.W;
                r.Height = obj.Rectangle.H;
                myRec.Add(r);
                // draw label
                Label la = new Label();
                la.Text = obj.ObjectProperty;
                la.Font = new Font("Consolas", 12, FontStyle.Bold);
                la.Parent = pictureBox1;
                la.Top = obj.Rectangle.Y - la.Height;
                la.Left = obj.Rectangle.X;
                la.BackColor = Color.Red;
                la.ForeColor = Color.White;
                la.AutoSize = true;
            }
            pictureBox1.Refresh();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            foreach (var r in myRec)
            {
                if (++counter == myColor.Count()) counter = 0;
                Pen myPen = new Pen(myColor[counter], 3);
                e.Graphics.DrawRectangle(myPen, r);
            }
        }
    }
}
