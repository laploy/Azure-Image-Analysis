﻿// Course: Azure Image Analysis
// Loy Vanich 2021
// detect object from a localy stored photo
// in .NET 5 console app

using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System;
using System.IO;
using System.Threading.Tasks;

namespace _0200_ObjectDetectConsoleCore
{
    class Program
    {
        static string subscriptionKey = "9f86dd377d9a4e61b452ac3304f68988";
        static string endpoint = "https://stu2021comvis.cognitiveservices.azure.com/";
        private const string myImage = @"L:\temp2\kitchen010.jpg";

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            ComputerVisionClient client = Authenticate(endpoint, subscriptionKey);
            DetectObjectsLocal(client, myImage).Wait();
            Console.WriteLine("Object detection is complete.");
        }

        static public ComputerVisionClient Authenticate(string endpoint, string key)
        {
            Console.WriteLine("Authenticate");
            ComputerVisionClient client =
              new ComputerVisionClient(new ApiKeyServiceClientCredentials(key))
              { Endpoint = endpoint };
            return client;
        }

        static public async Task DetectObjectsLocal(ComputerVisionClient client, string localImage)
        {
            Console.WriteLine("----------------------------------------------------------");
            Console.WriteLine("DETECT OBJECTS - LOCAL IMAGE");
            Console.WriteLine();

            using (Stream stream = File.OpenRead(localImage))
            {
                // Make a call to the Computer Vision service using the local file
                DetectResult results = await client.DetectObjectsInStreamAsync(stream);

                Console.WriteLine($"Detecting objects in local image {Path.GetFileName(localImage)}...");
                Console.WriteLine();

                // For each detected object in the picture, print out the bounding object detected, confidence of that detection and bounding box within the image
                Console.WriteLine("Detected objects:");
                foreach (var obj in results.Objects)
                {
                    Console.WriteLine($"{obj.ObjectProperty} with confidence {obj.Confidence} at location {obj.Rectangle.X}, " +
                      $"{obj.Rectangle.X + obj.Rectangle.W}, {obj.Rectangle.Y}, {obj.Rectangle.Y + obj.Rectangle.H}");
                }
                Console.WriteLine();
            }
        }
    }
}
