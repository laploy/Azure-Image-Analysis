﻿
// Course: Azure Image Analysis
// Loy Vanich 2021
// webcam and object detection

// Important: Nuget the OpenCvSharp4 to the project

// In the Tools -> Visual Studio Options Dialog -> Debugging -> 
// Check the "Redirect All Output Window Text to the Immediate Window" 



using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Threading;
using System.Windows.Forms;
using OpenCvSharp;
using OpenCvSharp.Extensions;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;

namespace _0240_DetectWebCam
{
    public partial class Form1 : Form
    {
        private string subscriptionKey = "9f86dd377d9a4e61b452ac3304f68988";
        private string endpoint = "https://stu2021comvis.cognitiveservices.azure.com/";
        private List<Rectangle> myRec = new List<Rectangle>();
        private Color[] myColor = { Color.Red, Color.Yellow, Color.SpringGreen, Color.Aqua };
        private int counter = 0;
        private string myImage = @"L:\temp2\myCap.jpg";

        private VideoCapture capture;
        private Mat frame;
        private Bitmap image;
        private Thread camera;
        private bool isCameraRunning = false;

        private void CaptureCamera()
        {
            camera = new Thread(new ThreadStart(CaptureCameraCallback));
            camera.Start();
        }

        private void CaptureCameraCallback()
        {
            frame = new Mat();
            capture = new VideoCapture(0);
            capture.Open(0);

            if (capture.IsOpened())
            {
                while (isCameraRunning)
                {

                    capture.Read(frame);
                    image = BitmapConverter.ToBitmap(frame);
                    if (pictureBox1.Image != null)
                    {
                        pictureBox1.Image.Dispose();
                    }
                    pictureBox1.Image = image;
                }
            }
        }

        public ComputerVisionClient Authenticate(string endpoint, string key)
        {
            textBox1.Text += "Authenticate\r\n";
            ComputerVisionClient client =
              new ComputerVisionClient(new ApiKeyServiceClientCredentials(key))
              { Endpoint = endpoint };
            return client;
        }

        public async Task DetectObjectsLocal(ComputerVisionClient client, string localImage)
        {
            textBox1.Text += $"Detecting objects in local image {Path.GetFileName(localImage)}...\r\n\r\n";
            using (Stream stream = File.OpenRead(localImage))
            {
                DetectResult results = await client.DetectObjectsInStreamAsync(stream);
                textBox1.Text += "Detected objects:\r\n\r\n";
                Rectangle r = new Rectangle();
                foreach (var obj in results.Objects)
                {
                    textBox1.Text += $"== {obj.ObjectProperty} ==\r\n" +    // detected object name
                        $"with confidence {obj.Confidence}\r\n" +
                        "at location " +
                        $"x: {obj.Rectangle.X}, " +
                        $"y: {obj.Rectangle.Y}, " +
                        $"h: {obj.Rectangle.H}, " +
                        $"w: {obj.Rectangle.W}" +
                        "\r\n\r\n";
                    // draw rectangle
                    r.X = obj.Rectangle.X;
                    r.Y = obj.Rectangle.Y;
                    r.Width = obj.Rectangle.W;
                    r.Height = obj.Rectangle.H;
                    myRec.Add(r);
                    // draw label
                    Label la = new Label();
                    la.Text = obj.ObjectProperty;
                    la.Font = new Font("Consolas", 12, FontStyle.Bold);
                    la.Parent = pictureBox1;
                    la.Top = obj.Rectangle.Y - la.Height;
                    la.Left = obj.Rectangle.X;
                    la.BackColor = Color.Red;
                    la.ForeColor = Color.White;
                    la.AutoSize = true;
                }
            }
            pictureBox1.Refresh();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            if (buttonStart.Text.Equals("Start"))
            {
                CaptureCamera();
                buttonStart.Text = "Stop";
                isCameraRunning = true;
            }
            else
            {
                capture.Release();
                buttonStart.Text = "Start";
                isCameraRunning = false;
            }
        }

        private void buttonCapture_Click(object sender, EventArgs e)
        {
            if (isCameraRunning)
            {
                Bitmap snapshot = new Bitmap(pictureBox1.Image);
                snapshot.Save(string.Format($@"L:\temp2\capture{DateTime.Now.Ticks}.png"), ImageFormat.Jpeg);
            }
            else
            {
                textBox1.Text += "Cannot take picture if the camera isn't capturing image!\r\n";
            }
        }

        private async void buttonDetect_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            pictureBox1.Load(myImage);
            ComputerVisionClient client = Authenticate(endpoint, subscriptionKey);
            await DetectObjectsLocal(client, myImage);
            textBox1.Text += "Object detection is complete.\r\n";
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            foreach (var r in myRec)
            {
                if (++counter == myColor.Count()) counter = 0;
                Pen myPen = new Pen(myColor[counter], 3);
                e.Graphics.DrawRectangle(myPen, r);
            }
        }
    }
}
