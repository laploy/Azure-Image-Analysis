﻿// Course: Azure Image Analysis
// Loy Vanich 2021
// object detection example ASP.NET Core

using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System;
using System.Threading.Tasks;
using System.Web;

namespace _0250_DetectWebApp.Pages
{
    public class IndexModel : PageModel
    {
        private string subscriptionKey = "9f86dd377d9a4e61b452ac3304f68988";
        private string endpoint = "https://stu2021comvis.cognitiveservices.azure.com/";
        private const string IMAGE_URL = "https://github.com/laploy/Azure-Image-Analysis/blob/main/images/cake020.jpg?raw=true";
        private string s = string.Empty;
        public string MyMessage { get; set; }
        private const string NL = "\r\n";

        public void OnGet()
        {
            MyMessage = "Press the button to start detection";
        }

        public void OnPostWork1()
        {
            ComputerVisionClient client = Authenticate(endpoint, subscriptionKey);
            //DetectObjectsOnline(client).Wait();
            s += "Object detection is complete" + NL;
            var ss = HttpUtility.HtmlEncode(s.Replace(Environment.NewLine, "<br>"));
            MyMessage = s;
        }

        private ComputerVisionClient Authenticate(string endpoint, string key)
        {
            s = "Authenticate" + NL;
            ComputerVisionClient client =
              new ComputerVisionClient(new ApiKeyServiceClientCredentials(key))
              { Endpoint = endpoint };
            return client;
        }

        private async Task DetectObjectsOnline(ComputerVisionClient client)
        {
            DetectResult results = await client.DetectObjectsAsync(IMAGE_URL);
            foreach (var obj in results.Objects)
            {
                s += $"== {obj.ObjectProperty} ==" + NL +    // detected object name
                    $"with confidence {obj.Confidence}" + NL +
                    "at location " +
                    $"x: {obj.Rectangle.X}, " + 
                    $"y: {obj.Rectangle.Y}, " + 
                    $"h: {obj.Rectangle.H}, " + 
                    $"w: {obj.Rectangle.W}" + NL+
                    "------------------" + NL;  
            }
        }
    }
}
