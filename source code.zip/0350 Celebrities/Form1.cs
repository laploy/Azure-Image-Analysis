﻿// Course: Azure Image Analysis
// Loy Vanich 2021
// Example: Celebrities detection

using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System.Collections.Generic;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Linq;

namespace test
{
    public partial class Form1 : Form
    {
        string subscriptionKey = "9f86dd377d9a4e61b452ac3304f68988";
        string endpoint = "https://stu2021comvis.cognitiveservices.azure.com/";
        private const string myImage = @"L:\temp2\harrypotter010.jpg";
        private const string NL = "\r\n";
        private List<Rectangle> myRec = new List<Rectangle>();
        private Color[] myColor = { Color.Red, Color.Yellow, Color.SpringGreen, Color.Aqua };
        private int myCounter = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Load(myImage);
        }

        public ComputerVisionClient Authenticate(string endpoint, string key)
        {
            textBox1.Text += $"Authenticate{NL}{NL}";
            ComputerVisionClient client =
              new ComputerVisionClient(new ApiKeyServiceClientCredentials(key))
              { Endpoint = endpoint };
            return client;
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            ComputerVisionClient client = Authenticate(endpoint, subscriptionKey);
            await AnalyzeLocal(client, myImage);
            textBox1.Text += $"Task complete{NL}";
        }

        public async Task AnalyzeLocal(ComputerVisionClient client, string localImage)
        {
            textBox1.Text += $"Analyzing local image: " + 
                $"{Path.GetFileName(localImage)}...{NL}{NL}";

            List<VisualFeatureTypes?> myFeature = new List<VisualFeatureTypes?>()
            {
                VisualFeatureTypes.Faces, VisualFeatureTypes.Description
            };

            ImageAnalysis myResult;
            using (Stream myStream = File.OpenRead(localImage))
            {
                myResult = await client.AnalyzeImageInStreamAsync(myStream, visualFeatures: myFeature);
            }
            textBox1.Text += $"Got analyze result!{NL}{NL}";

            string s = string.Empty;
            if (null != myResult.Description.Captions)
            {
                foreach (var v in myResult.Description.Captions)
                {
                    textBox1.Text += $"{v.Text} {v.Confidence}";
                    s = v.Text;
                }
            }
            var myName = s.Split(',');
            var lastName = myName[myName.Count() - 1].Split(' ');
            myName[myName.Count() - 1] = lastName[1] + " " + lastName[2];

            int c = 0;
            if (null != myResult.Faces)
            {
                textBox1.Text += $"Faces:{NL}";
                Rectangle myRec = new Rectangle();

                foreach (var v in myResult.Faces)
                {
                    textBox1.Text += $"{v.Gender} {v.Age}{NL}";
                    // draw rectangle
                    myRec.X = v.FaceRectangle.Left;
                    myRec.Y = v.FaceRectangle.Top;
                    myRec.Width = v.FaceRectangle.Width;
                    myRec.Height = v.FaceRectangle.Height;
                    this.myRec.Add(myRec);
                    // draw label
                    Label myLabel = new Label();
                    myLabel.Text = myName[c++].Trim();
                    myLabel.Font = new Font("Consolas", 12, FontStyle.Bold);
                    myLabel.Parent = pictureBox1;
                    myLabel.Top = v.FaceRectangle.Top - myLabel.Height;
                    myLabel.Left = v.FaceRectangle.Left;
                    myLabel.BackColor = Color.Red;
                    myLabel.ForeColor = Color.White;
                    myLabel.AutoSize = true;
                }
                pictureBox1.Refresh();
            }
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            foreach (var r in myRec)
            {
                if (++myCounter == myColor.Count()) myCounter = 0;
                Pen myPen = new Pen(myColor[myCounter], 3);
                e.Graphics.DrawRectangle(myPen, r);
            }
        }
    }
}
