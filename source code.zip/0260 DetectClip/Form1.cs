﻿// Course: Azure Image Analysis
// Loy Vanich 2021
// Load and play and capture mp4 video clip

using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Threading;
using System.Windows.Forms;
using OpenCvSharp;
using OpenCvSharp.Extensions;
using Size = OpenCvSharp.Size;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;


namespace _0260_DetectClip
{
    public partial class Form1 : Form
    {
        private string subscriptionKey = "9f86dd377d9a4e61b452ac3304f68988";
        private string endpoint = "https://stu2021comvis.cognitiveservices.azure.com/";
        private List<Rectangle> myRec = new List<Rectangle>();
        private Color[] myColor = { Color.Red, Color.Yellow, Color.SpringGreen, Color.Aqua };
        private int counter = 0;

        private bool isRun = false;
        private VideoCapture myVideo;
        private Mat myImage;
        private Thread myThread;
        private const string VIDEO_FILE = @"L:\temp2\bkkwalk1.mp4";
        private const string CAPTURE_FILE = @"L:\temp2\capture.jpg";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            myImage = new Mat();
            myThread = new Thread(new ThreadStart(VidCallback));
            myThread.Start();
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            myVideo = new VideoCapture(VIDEO_FILE);
            isRun = true;
        }

        private async void buttonCapture_Click(object sender, EventArgs e)
        {
            if (isRun)
            {
                Bitmap snapshot = new Bitmap(pictureBox1.Image);
                snapshot.Save(CAPTURE_FILE, ImageFormat.Jpeg);
                StopVideo();
                buttonStart.Enabled = false;
                pictureBox1.Load(CAPTURE_FILE);
                textBox1.Text = string.Empty;
                ComputerVisionClient client = Authenticate(endpoint, subscriptionKey);
                await DetectObjectsLocal(client, CAPTURE_FILE);
                textBox1.Text += "Object detection is complete.\r\n";
            }
            else
            {
                textBox1.Text = "Error: vid is not running";
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            StopVideo();
            Application.Exit();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            foreach (var r in myRec)
            {
                if (++counter == myColor.Count()) counter = 0;
                Pen myPen = new Pen(myColor[counter], 3);
                e.Graphics.DrawRectangle(myPen, r);
            }
        }

        private void VidCallback()
        {
            while (true)
            {
                if (!isRun) continue;
                myVideo.Read(myImage);
                if (myImage.Empty()) return;
                var imageRes = new Mat();
                Cv2.Resize(myImage, imageRes, new Size(640, 360));
                var frame = BitmapConverter.ToBitmap(imageRes);
                pictureBox1.Image = frame;
                Thread.Sleep(30);
            }
        }

        private void StopVideo()
        {
            isRun = false;
            Thread.Sleep(100);
            myThread.Interrupt();
            myVideo.Release();
        }

        public ComputerVisionClient Authenticate(string endpoint, string key)
        {
            textBox1.Text += "Authenticate\r\n";
            ComputerVisionClient client =
              new ComputerVisionClient(new ApiKeyServiceClientCredentials(key))
              { Endpoint = endpoint };
            return client;
        }

        public async Task DetectObjectsLocal(ComputerVisionClient client, string localImage)
        {
            textBox1.Text += $"Detecting objects in local image {Path.GetFileName(localImage)}...\r\n\r\n";
            using (Stream stream = File.OpenRead(localImage))
            {
                DetectResult results = await client.DetectObjectsInStreamAsync(stream);
                textBox1.Text += "Detected objects:\r\n\r\n";
                Rectangle r = new Rectangle();
                foreach (var obj in results.Objects)
                {
                    textBox1.Text += $"== {obj.ObjectProperty} ==\r\n" +    // detected object name
                        $"with confidence {obj.Confidence}\r\n" +
                        "at location " +
                        $"x: {obj.Rectangle.X}, " +
                        $"y: {obj.Rectangle.Y}, " +
                        $"h: {obj.Rectangle.H}, " +
                        $"w: {obj.Rectangle.W}" +
                        "\r\n\r\n";
                    // draw rectangle
                    r.X = obj.Rectangle.X;
                    r.Y = obj.Rectangle.Y;
                    r.Width = obj.Rectangle.W;
                    r.Height = obj.Rectangle.H;
                    myRec.Add(r);
                    // draw label
                    Label myLabel = new Label();
                    myLabel.Text = obj.ObjectProperty;
                    myLabel.Font = new Font("Consolas", 12, FontStyle.Bold);
                    myLabel.Parent = pictureBox1;
                    myLabel.Top = obj.Rectangle.Y - myLabel.Height;
                    myLabel.Left = obj.Rectangle.X;
                    myLabel.BackColor = Color.Red;
                    myLabel.ForeColor = Color.White;
                    myLabel.AutoSize = true;
                }
            }
            pictureBox1.Refresh();
        }
    }
}
