﻿// Course: Azure Image Analysis
// Loy Vanich 2021
// Example: Get Area of Interest

using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test
{
    public partial class Form1 : Form
    {
        string subscriptionKey = "9f86dd377d9a4e61b452ac3304f68988";
        string endpoint = "https://stu2021comvis.cognitiveservices.azure.com/";
        private const string myImage = @"L:\temp2\star010.jpg";
        string localSavePath = @"L:\temp2";
        private const string NL = "\r\n";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Load(myImage);
            pictureBox2.Left = pictureBox1.Left + pictureBox1.Width + 10;
            pictureBox2.Width = Convert.ToInt32(pictureBox1.Width / 2);
            pictureBox2.Height = pictureBox1.Height;
            this.Width = pictureBox1.Width + pictureBox2.Width + 50;
        }

        public ComputerVisionClient Authenticate(string endpoint, string key)
        {
            textBox1.Text += $"Authenticate{NL}";
            ComputerVisionClient client =
              new ComputerVisionClient(new ApiKeyServiceClientCredentials(key))
              { Endpoint = endpoint };
            return client;
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            ComputerVisionClient client = Authenticate(endpoint, subscriptionKey);
            await AnalyzeLocal(client, myImage);
            textBox1.Text += $"Task complete{NL}";
        }

        public async Task AnalyzeLocal(ComputerVisionClient client, string localImage)
        {
            textBox1.Text += $"Geting area of interest.{NL}";
            int myWidth = Convert.ToInt32(pictureBox1.Width/2);
            int myHeight = pictureBox1.Height;
            using (Stream imageStream = File.OpenRead(localImage))
            {
                Stream result = await client.GenerateThumbnailInStreamAsync(myWidth, myHeight, imageStream, smartCropping: true);
                string imageName = Path.GetFileName(localImage);
                string newImageName = imageName.Insert(imageName.Length - 4, "_new");
                string newPath = Path.Combine(localSavePath, newImageName);
                textBox1.Text += $"Area of interest file saved = {newPath}{NL}";
                using (Stream file = File.Create(newPath)) { result.CopyTo(file); }
                pictureBox2.Load($"{localSavePath}\\{newImageName}");
            }
        }
    }
}
