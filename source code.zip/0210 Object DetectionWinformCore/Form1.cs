﻿// Course: Azure Image Analysis
// Loy Vanich 2021
// Example: Object detection in .NET Core 5 Winform
// Add NuGet package
// Microsoft.Azure.CognitiveServices.Vision.ComputerVision

using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0210_Object_DetectionWinformCore
{
    public partial class Form1 : Form
    {
        string subscriptionKey = "9f86dd377d9a4e61b452ac3304f68988";
        string endpoint = "https://stu2021comvis.cognitiveservices.azure.com/";
        private const string myImage = @"L:\temp2\kitchen010.jpg";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Load(myImage);
        }

        public ComputerVisionClient Authenticate(string endpoint, string key)
        {
            textBox1.Text += "Authenticate\r\n";
            ComputerVisionClient client =
              new ComputerVisionClient(new ApiKeyServiceClientCredentials(key))
              { Endpoint = endpoint };
            return client;
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            ComputerVisionClient client = Authenticate(endpoint, subscriptionKey);
            await DetectObjectsLocal(client, myImage);
            textBox1.Text += "Object detection is complete.\r\n";
        }

        public async Task DetectObjectsLocal(ComputerVisionClient client, string localImage)
        {
            textBox1.Text += $"Detecting objects in local image {Path.GetFileName(localImage)}...\r\n\r\n";
            using (Stream stream = File.OpenRead(localImage))
            {
                DetectResult results = await client.DetectObjectsInStreamAsync(stream);
                textBox1.Text += "Detected objects:\r\n\r\n";
                foreach (var obj in results.Objects)
                {
                    textBox1.Text += $"== {obj.ObjectProperty} ==\r\n" +    // detected object name
                        $"with confidence {obj.Confidence}\r\n" + 
                        "at location " + 
                        $"{obj.Rectangle.X}, " +
                        $"{obj.Rectangle.X + obj.Rectangle.W}, " + 
                        $"{obj.Rectangle.Y}, " + 
                        $"{obj.Rectangle.Y + obj.Rectangle.H}" + 
                        "\r\n\r\n";
                }
            }
        }
    }
}
